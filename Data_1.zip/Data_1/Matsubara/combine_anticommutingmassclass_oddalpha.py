import numpy as np

savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Misc/IntegralCalculation/Combined_Trace_Results/AntiCommutingMassClass'
datadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Misc/IntegralCalculation/Saved_Trace_Values_AntiCommutingMassClass'

alphalist = [0.1, 0.3, 0.5, 0.7, 0.9]
temperaturelist = ['0.01', '0.001', '0.0001']

for temperature in temperaturelist:
    for alpha in alphalist:

        data = np.loadtxt(datadir + '/honeycombPBC_nl16a{}_temperature{}_summationindexbound3000_AntiCommuteMassClass_traceresults.txt'.format(alpha, temperature),
                          dtype=np.complex128)

        datamore = np.loadtxt(datadir + '/honeycombPBC_nl16a{}_temperature{}_ogsummationindexbound3000_newsummationindexbound4000_traceresults_MORE.txt'.format(alpha, temperature),
                               dtype=np.complex128)

        whole_data = np.concatenate((datamore[0], data, datamore[1]))

        print(np.max(np.abs(np.imag(whole_data))))
        np.savetxt(savedir + '/honeycombPBC_nl16a{}_temperature{}_summationbounds4000_AntiCommuteMassClass_traceresults.txt'.format(alpha,temperature),
                   np.real(whole_data))
